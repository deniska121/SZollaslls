
local PANEL = {}

AccessorFunc( PANEL, "m_strModel", "Model" )
AccessorFunc( PANEL, "m_pOrigin", "Origin" )
AccessorFunc( PANEL, "m_bCustomIcon", "CustomIcon" )

function PANEL:Init()

	self:SetTitle( "#smwidget.icon_editor" )

	-- This is overwritten in SetIcon
	self:SetSize( 750, 500 )

	self:SetSizable( true )
	self:SetMinWidth( 650 )
	self:SetMinHeight( 270 )

	local left = self:Add( "Panel" )
	left:Dock( FILL )
	self.LeftPanel = left

		local previewCont = left:Add( "Panel" )
		previewCont:Dock( FILL )
		previewCont:DockMargin( 0, 0, 0, 4 )

		self.SpawnIcon = previewCont:Add( "SpawnIcon" )
		self.SpawnIcon:SetPaintedManually( true )
		--self.SpawnIcon.DoClick = function() self:RenderIcon() end

		local previewBG = previewCont:Add( "Panel" )
		previewBG:DockMargin( 0, 0, 0, 4 )
		previewBG.Paint = function( s, w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 128 ) )

			-- I kinda hate where this is positioned, but at least draw it over the background
			self.SpawnIcon:PaintManual()
		end
		function previewBG.PerformLayout( thisPnl )
			-- Generic "fit in box" algorithm
			local icnW, icnH = self.SpawnIcon:GetSize()
			local scale = math.min( previewCont:GetWide() / icnW,
									previewCont:GetTall() / icnH )

			thisPnl:SetSize( icnW * scale, icnH * scale )
			thisPnl:Center()
		end
		function previewCont.PerformLayout( thisPnl )
			previewBG:PerformLayout()
		end

		self.ModelPanel = previewBG:Add( "DAdjustableModelPanel" )
		self.ModelPanel.FarZ = 32768
		self.ModelPanel:Dock( FILL )

		local mat_wireframe = Material( "models/wireframe" )
		function self.ModelPanel.PostDrawModel( mdlpnl, ent )
			if ( self.ShowOriginPnl:GetChecked() ) then
				render.DrawLine( vector_origin, Vector( 0, 0, 100 ), Color( 0, 0, 255 ) )
				render.DrawLine( vector_origin, Vector( 0, 100, 0 ), Color( 0, 255, 0 ) )
				render.DrawLine( vector_origin, Vector( 100, 0, 0 ), Color( 255, 0, 0 ) )
			end

			if ( self.ShowBBoxPnl:GetChecked() ) then
				local mins, maxs = ent:GetRenderBounds()
				local scale = 1
				mat_wireframe:SetVector( "$color", Vector( 1, 1, 1 ) )
				render.SetMaterial( mat_wireframe )

				render.DrawBox( ent:GetPos(), ent:GetAngles(), mins * scale, maxs * scale )
			end

		end
		function self.ModelPanel:PreDrawModel()
			-- Use local lights as it produces much better looking rendering than the light box
			if ( self.LocalLights ) then
				render.SetLocalModelLights( self.LocalLights )
			end

			-- This allows us to have consistent preview, regardless of current map location
			render.BindLocalCubemap( "editor/cubemap" )
			return true
		end

	local controls = left:Add( "Panel" )
	controls:SetTall( 64 )
	controls:Dock( BOTTOM )

		local controls_anim = controls:Add( "Panel" )
		controls_anim:SetTall( 20 )
		controls_anim:Dock( TOP )
		controls_anim:DockMargin( 0, 0, 0, 4 )
		controls_anim:MoveToBack()

			self.AnimTrack = controls_anim:Add( "DSlider" )
			self.AnimTrack:Dock( FILL )
			self.AnimTrack:SetNotches( 100 )
			self.AnimTrack:SetTrapInside( true )
			self.AnimTrack:SetLockY( 0.5 )

			self.AnimPause = controls_anim:Add( "DImageButton" )
			self.AnimPause:SetImage( "icon16/control_pause_blue.png" )
			self.AnimPause:SetStretchToFit( false )
			self.AnimPause:SetPaintBackground( true )
			self.AnimPause:SetIsToggle( true )
			self.AnimPause:SetToggle( false )
			self.AnimPause:Dock( LEFT )
			self.AnimPause:SetWide( 32 )

		local BestGuess = controls:Add( "DImageButton" )
		BestGuess:SetImage( "icon32/wand.png" )
		BestGuess:SetStretchToFit( false )
		BestGuess:SetPaintBackground( true )
		BestGuess.DoClick = function() self:BestGuessLayout() end
		BestGuess:Dock( LEFT )
		BestGuess:DockMargin( 0, 0, 0, 0 )
		BestGuess:SetWide( 50 )
		BestGuess:SetTooltip( "Best Guess" )

		local FullFrontal = controls:Add( "DImageButton" )
		FullFrontal:SetImage( "icon32/hand_point_090.png" )
		FullFrontal:SetStretchToFit( false )
		FullFrontal:SetPaintBackground( true )
		FullFrontal.DoClick = function() self:FullFrontalLayout() end
		FullFrontal:Dock( LEFT )
		FullFrontal:DockMargin( 2, 0, 0, 0 )
		FullFrontal:SetWide( 50 )
		FullFrontal:SetTooltip( "Front" )

		local Above = controls:Add( "DImageButton" )
		Above:SetImage( "icon32/hand_property.png" )
		Above:SetStretchToFit( false )
		Above:SetPaintBackground( true )
		Above.DoClick = function() self:AboveLayout() end
		Above:Dock( LEFT )
		Above:DockMargin( 2, 0, 0, 0 )
		Above:SetWide( 50 )
		Above:SetTooltip( "Above" )

		local Right = controls:Add( "DImageButton" )
		Right:SetImage( "icon32/hand_point_180.png" )
		Right:SetStretchToFit( false )
		Right:SetPaintBackground( true )
		Right.DoClick = function() self:RightLayout() end
		Right:Dock( LEFT )
		Right:DockMargin( 2, 0, 0, 0 )
		Right:SetWide( 50 )
		Right:SetTooltip( "Right" )

		local Origin = controls:Add( "DImageButton" )
		Origin:SetImage( "icon32/hand_point_090.png" )
		Origin:SetStretchToFit( false )
		Origin:SetPaintBackground( true )
		Origin.DoClick = function() self:OriginLayout() end
		Origin:Dock( LEFT )
		Origin:DockMargin( 2, 0, 0, 0 )
		Origin:SetWide( 50 )
		Origin:SetTooltip( "Center" )

		local Render = controls:Add( "DButton" )
		Render:SetText( "RENDER" )
		Render.DoClick = function() self:RenderIcon() end
		Render:Dock( RIGHT )
		Render:DockMargin( 2, 0, 0, 0 )
		Render:SetWide( 50 )
		Render:SetTooltip( "Render Icon" )

		local Picker = controls:Add( "DImageButton" )
		Picker:SetImage( "icon32/color_picker.png" )
		Picker:SetStretchToFit( false )
		Picker:SetPaintBackground( true )
		Picker:Dock( RIGHT )
		Picker:DockMargin( 2, 0, 0, 0 )
		Picker:SetWide( 50 )
		Picker:SetTooltip( "Pick a new model from an entity" )
		Picker.DoClick = function()

			self:SetVisible( false )

			util.worldpicker.Start( function( tr )

				self:SetVisible( true )

				if ( !IsValid( tr.Entity ) ) then return end

				self:SetFromEntity( tr.Entity )

			end )
		end

	local right = self:Add( "DPropertySheet" )
	right:Dock( RIGHT )
	right:SetPadding( 0 )
	right:DockMargin( 4, 0, 0, 0 )
	right:SetWide( 268 )
	self.PropertySheet = right

	-- Animations

	local anims = right:Add( "Panel" )
	anims:Dock( FILL )
	anims:DockPadding( 2, 0, 2, 2 )
	right:AddSheet( "#smwidget.animations", anims, "icon16/monkey.png" )

		self.AnimList = anims:Add( "DListView" )
		self.AnimList:AddColumn( "name" )
		self.AnimList:Dock( FILL )
		self.AnimList:SetMultiSelect( false )
		self.AnimList:SetHideHeaders( true )

		self.AnimList.OnRowSelected = function( _, _, line )
			local ent = self.ModelPanel:GetEntity()
			if ( !IsValid( ent ) ) then return end

			local speed = ent:GetPlaybackRate()
			ent:ResetSequence( line:GetColumnText( 1 ) )
			ent:SetCycle( 0 )
			ent:SetPlaybackRate( speed )
			if ( speed < 0 ) then ent:SetCycle( 1 ) end
		end

		self.AnimList.OnRowRightClick = function( _, _, line )
			local menu = DermaMenu( false, line )

			menu:AddOption( "#spawnmenu.menu.copy", function()
				SetClipboardText( line:GetColumnText( 1 ) )
			end ):SetIcon("icon16/page_copy.png")

			menu:Open()
		end

		self.AnimSearch = anims:Add( "DTextEntry" )
		self.AnimSearch:Dock( TOP )
		self.AnimSearch:DockMargin( 0, 0, 0, 2 )
		self.AnimSearch:SetPlaceholderText( "#spawnmenu.filter" )
		self.AnimSearch.OnChange = function( p )
			local ent = self.ModelPanel:GetEntity()
			if ( !IsValid( ent ) ) then return end

			self:FillAnimations( ent, p:GetText() )
		end

	-- Bodygroups

	local pnl = right:Add( "Panel" )
	pnl:Dock( FILL )
	pnl:DockPadding( 7, 0, 7, 7 )

	self.BodygroupTab = right:AddSheet( "#smwidget.bodygroups", pnl, "icon16/brick.png" )

		self.BodyList = pnl:Add( "DScrollPanel" )
		self.BodyList:Dock( FILL )

			--This kind of works but they don't move their stupid mouths. So fuck off.
			--[[
			self.Scenes = pnl:Add( "DTree" )
			self.Scenes:Dock( BOTTOM )
			self.Scenes:SetSize( 200, 200 )
			self.Scenes.DoClick = function( _, node )

				if ( !node.FileName ) then return end
				local ext = string.GetExtensionFromFilename( node.FileName )
				if( ext != "vcd" ) then return end

				self.ModelPanel:StartScene( node.FileName )
				MsgN( node.FileName )

			end

			local materials = self.Scenes.RootNode:AddFolder( "Scenes", "scenes/", true )
			materials:SetIcon( "icon16/photos.png" )--]]

	-- Settings

	local settings = right:Add( "Panel" )
	settings:Dock( FILL )
	settings:DockPadding( 7, 0, 7, 7 )
	right:AddSheet( "#smwidget.settings", settings, "icon16/cog.png" )

		local bbox = settings:Add( "DCheckBoxLabel" )
		bbox:SetText( "Show Bounding Box" )
		bbox:Dock( TOP )
		bbox:DockMargin( 0, 0, 0, 3 )
		bbox:SetDark( true )
		bbox:SetCookieName( "model_editor_bbox" )
		self.ShowBBoxPnl = bbox

		local origin = settings:Add( "DCheckBoxLabel" )
		origin:SetText( "Show Origin" )
		origin:Dock( TOP )
		origin:SetDark( true )
		origin:SetCookieName( "model_editor_origin" )
		self.ShowOriginPnl = origin

		local playSpeed = settings:Add( "DNumSlider" )
		playSpeed:SetText( "Playback Speed" )
		playSpeed:Dock( TOP )
		playSpeed:SetValue( 1 )
		playSpeed:SetMinMax( -1, 2 )
		playSpeed:SetDark( true )
		playSpeed.OnValueChanged = function( s, value )
			self.ModelPanel:GetEntity():SetPlaybackRate( value )
		end

		local moveSpeed = settings:Add( "DNumSlider" )
		moveSpeed:SetText( "Move Speed" )
		moveSpeed:Dock( TOP )
		moveSpeed:SetMinMax( 0.5, 8 )
		moveSpeed:SetValue( 1 )
		moveSpeed:SetDark( true )
		moveSpeed.OnValueChanged = function( p )
			self.ModelPanel:SetMovementScale( p:GetValue() )
		end
		moveSpeed:SetCookieName( "iconeditor_movespeed" )

		local angle = settings:Add( "DTextEntry" )
		angle:SetTooltip( "Entity Angles" )
		angle:Dock( TOP )
		angle:DockMargin( 0, 0, 0, 3 )
		angle:SetZPos( 100 )
		angle.OnChange = function( p )
			self.ModelPanel:GetEntity():SetAngles( Angle( p:GetText() ) )
		end
		self.TargetAnglePanel = angle

		local cam_angle = settings:Add( "DTextEntry" )
		cam_angle:SetTooltip( "Camera Angles" )
		cam_angle:Dock( TOP )
		cam_angle:DockMargin( 0, 0, 0, 3 )
		cam_angle:SetZPos( 101 )
		cam_angle.OnChange = function( p )
			self.ModelPanel:SetLookAng( Angle( p:GetText() ) )
		end
		self.TargetCamAnglePanel = cam_angle

		local cam_pos = settings:Add( "DTextEntry" )
		cam_pos:SetTooltip( "Camera Position" )
		cam_pos:Dock( TOP )
		cam_pos:DockMargin( 0, 0, 0, 3 )
		cam_pos:SetZPos( 102 )
		cam_pos.OnChange = function( p )
			self.ModelPanel:SetCamPos( Vector( p:GetText() ) )
		end
		self.TargetCamPosPanel = cam_pos

		local cam_fov = settings:Add( "DNumSlider" )
		cam_fov:SetText( "Camera FOV" )
		cam_fov:Dock( TOP )
		cam_fov:DockMargin( 0, 0, 0, 3 )
		cam_fov:SetZPos( 103 )
		cam_fov:SetMinMax( 0.001, 179 )
		cam_fov:SetDark( true )
		cam_fov.OnValueChanged = function( p )
			self.ModelPanel:SetFOV( p:GetValue() )
		end
		self.TargetCamFOVPanel = cam_fov

		local copypaste_cam = settings:Add( "Panel" )
		copypaste_cam:SetTall( 20 )
		copypaste_cam:Dock( TOP )
		copypaste_cam:SetZPos( 104 )
		copypaste_cam:DockMargin( 0, 0, 0, 4 )

			local copy = copypaste_cam:Add( "DButton" )
			copy:Dock( FILL )
			copy:SetText( "Copy Camera Settings" )
			copy:DockMargin( 0, 0, 3, 0 )
			copy.DoClick = function() SetClipboardText( util.TableToJSON( {
				pos = self.ModelPanel:GetCamPos(),
				ang = self.ModelPanel:GetLookAng(),
				fov = self.ModelPanel:GetFOV(),
				mdl_ang = self.ModelPanel:GetEntity():GetAngles()
			} ) ) end

			local paste = copypaste_cam:Add( "DTextEntry" )
			paste:SetWide( 140 ) -- Ew
			paste:Dock( RIGHT )
			paste:SetPlaceholderText( "Paste Camera Settings Here" )
			paste.OnChange = function( p )
				local tabl = util.JSONToTable( p:GetText() )
				if ( tabl ) then
					self.ModelPanel:SetCamPos( tabl.pos )
					self.ModelPanel:SetLookAng( tabl.ang )
					self.ModelPanel:SetFOV( tabl.fov )
					self.ModelPanel:GetEntity():SetAngles( tabl.mdl_ang )
				end
				p:SetText( "" )
			end

		local labels = { "Pitch", "Yaw", "Roll" }
		for i = 1, 3 do
			local rotate45 = settings:Add( "DButton" )
			rotate45:SetText( "Rotate Entity +/-45 " .. labels[ i ] )
			rotate45:Dock( TOP )
			rotate45:DockMargin( 0, 0, 0, 3 )
			rotate45:SetZPos( 110 + i )
			rotate45.DoClick = function( p )
				local aang = self.ModelPanel:GetEntity():GetAngles()
				aang[ i ] = aang[ i ] + 45
				self.ModelPanel:GetEntity():SetAngles( aang )
			end
			rotate45.DoRightClick = function( p )
				local aang = self.ModelPanel:GetEntity():GetAngles()
				aang[ i ] = aang[ i ] - 45
				self.ModelPanel:GetEntity():SetAngles( aang )
			end
		end

	-- Lighting Setups

	local lightPresets = right:Add( "Panel" )
	lightPresets:Dock( FILL )
	lightPresets:DockPadding( 7, 0, 7, 7 )
	right:AddSheet( "Lights", lightPresets, "icon16/lightbulb.png" )

		self.LightPresets = lightPresets:Add( "DScrollPanel" )
		self.LightPresets:Dock( FILL )

		local defLights = self.LightPresets:Add( "DButton" )
		defLights:SetText( "Default Lighting" )
		defLights:Dock( TOP )
		defLights:DockMargin( 0, 0, 0, 3 )
		defLights.DoClick = function( p )
			self:SetDefaultLighting()
		end

		local exp1 = self.LightPresets:Add( "DButton" )
		exp1:SetText( "Experimental Character Lighting" )
		exp1:Dock( TOP )
		exp1:DockMargin( 0, 0, 0, 3 )
		exp1.DoClick = function( p )
			-- Remove base lighting
			local baseClr = Color( 0, 0, 0 )
			self.ModelPanel:SetDirectionalLight( BOX_FRONT, baseClr )
			self.ModelPanel:SetDirectionalLight( BOX_BACK, baseClr )
			self.ModelPanel:SetDirectionalLight( BOX_RIGHT, baseClr )
			self.ModelPanel:SetDirectionalLight( BOX_LEFT, baseClr )
			self.ModelPanel:SetDirectionalLight( BOX_TOP, baseClr )
			self.ModelPanel:SetDirectionalLight( BOX_BOTTOM, baseClr )

			-- Apply CoOl lights
			self.ModelPanel.LocalLights = {
				-- left
				{
					type = MATERIAL_LIGHT_POINT,
					pos = Vector( -100, -50, 72 ),
					color = Vector( 0.3, 0.6, 1 ) * 0.3
				},
				-- right
				{
					type = MATERIAL_LIGHT_POINT,
					pos = Vector( 0, 100, 72 ),
					color = Vector( 1, 0.6, 0.3 ) * 0.1
				},
				-- front
				{
					type = MATERIAL_LIGHT_POINT,
					pos = Vector( 100, 24, 72 ),
					color = Vector( 1, 1, 1 ) * 1
				}
			}
		end

end

function PANEL:OnKeyCodePressed( code )
	if ( code != KEY_UP && code != KEY_DOWN ) then return end

	local line = self.AnimList:GetSelectedLine()
	if ( !line ) then return end
	local direction = code == KEY_UP && -1 or 1

	line = self.AnimList:GetLine( line + direction )
	if ( !IsValid( line ) ) then return end

	self.AnimList:ClearSelection()
	self.AnimList:SelectItem( line )
end

function PANEL:SetDefaultLighting()

	self.ModelPanel:SetAmbientLight( Color( 255 * 0.3, 255 * 0.3, 255 * 0.3 ) )

	-- Since Color() clamps the values, we gotta do a little hack to match whats in the engine
	local frontColor = Color( 255, 255, 255 )
	frontColor.r = 255 * 1.3
	frontColor.g = frontColor.r
	frontColor.b = frontColor.r
	local topColor = Color( 255, 255, 255 )
	topColor.r = 255 * 2.3
	topColor.g = topColor.r
	topColor.b = topColor.r

	self.ModelPanel:SetDirectionalLight( BOX_FRONT, frontColor )
	self.ModelPanel:SetDirectionalLight( BOX_BACK, Color( 255 * 0.2, 255 * 0.2, 255 * 0.2 ) )
	self.ModelPanel:SetDirectionalLight( BOX_RIGHT, Color( 255 * 0.2, 255 * 0.2, 255 * 0.2 ) )
	self.ModelPanel:SetDirectionalLight( BOX_LEFT, Color( 255 * 0.2, 255 * 0.2, 255 * 0.2 ) )
	self.ModelPanel:SetDirectionalLight( BOX_TOP, topColor )
	self.ModelPanel:SetDirectionalLight( BOX_BOTTOM, Color( 255 * 0.1, 255 * 0.1, 255 * 0.1 ) )

	self.ModelPanel.LocalLights = nil

end

function PANEL:BestGuessLayout()

	local ent = self.ModelPanel:GetEntity()
	if ( !IsValid( ent ) ) then return end

	local pos = ent:GetPos()
	local ang = ent:GetAngles()

	local tab = PositionSpawnIcon( ent, pos, true )

	ent:SetAngles( ang )
	if ( tab ) then
		self.ModelPanel:SetCamPos( tab.origin )
		self.ModelPanel:SetFOV( tab.fov )
		self.ModelPanel:SetLookAng( tab.angles )
	end

end

function PANEL:FullFrontalLayout()

	local ent = self.ModelPanel:GetEntity()
	if ( !IsValid( ent ) ) then return end

	local pos = ent:GetPos()
	local campos = pos + Vector( -200, 0, 0 )

	self.ModelPanel:SetCamPos( campos )
	self.ModelPanel:SetFOV( 45 )
	self.ModelPanel:SetLookAng( ( campos * -1 ):Angle() )

end

function PANEL:AboveLayout()

	local ent = self.ModelPanel:GetEntity()
	if ( !IsValid( ent ) ) then return end

	local pos = ent:GetPos()
	local campos = pos + Vector( 0, 0, 200 )

	self.ModelPanel:SetCamPos( campos )
	self.ModelPanel:SetFOV( 45 )
	self.ModelPanel:SetLookAng( ( campos * -1 ):Angle() )

end

function PANEL:RightLayout()

	local ent = self.ModelPanel:GetEntity()
	if ( !IsValid( ent ) ) then return end

	local pos = ent:GetPos()
	local campos = pos + Vector( 0, 200, 0 )

	self.ModelPanel:SetCamPos( campos )
	self.ModelPanel:SetFOV( 45 )
	self.ModelPanel:SetLookAng( ( campos * -1 ):Angle() )

end

function PANEL:OriginLayout()

	local ent = self.ModelPanel:GetEntity()
	if ( !IsValid( ent ) ) then return end

	local pos = ent:GetPos()
	local campos = pos + vector_origin

	self.ModelPanel:SetCamPos( campos )
	self.ModelPanel:SetFOV( 45 )
	self.ModelPanel:SetLookAng( Angle( 0, -180, 0 ) )

end

function PANEL:UpdateEntity( ent )

	ent:SetEyeTarget( self.ModelPanel:GetCamPos() )

	if ( IsValid( self.TargetAnglePanel ) && !self.TargetAnglePanel:IsEditing() && !self.TargetAnglePanel:IsHovered() ) then
		self.TargetAnglePanel:SetText( tostring( ent:GetAngles() ) )
	end
	if ( IsValid( self.TargetCamAnglePanel ) && !self.TargetCamAnglePanel:IsEditing() && !self.TargetCamAnglePanel:IsHovered() ) then
		self.TargetCamAnglePanel:SetText( tostring( self.ModelPanel:GetLookAng() ) )
	end
	if ( IsValid( self.TargetCamPosPanel ) && !self.TargetCamPosPanel:IsEditing() && !self.TargetCamPosPanel:IsHovered() ) then
		self.TargetCamPosPanel:SetText( tostring( self.ModelPanel:GetCamPos() ) )
	end
	if ( IsValid( self.TargetCamFOVPanel ) && !self.TargetCamFOVPanel:IsEditing() && !self.TargetCamFOVPanel:IsHovered() ) then
		self.TargetCamFOVPanel:SetValue( self.ModelPanel:GetFOV() )
	end

	if ( self.AnimTrack:GetDragging() ) then

		ent:SetCycle( self.AnimTrack:GetSlideX() )
		self.AnimPause:SetToggle( true )

	elseif ( ent:GetCycle() != self.AnimTrack:GetSlideX() ) then

		local cyc = ent:GetCycle()
		if ( cyc < 0 ) then cyc = cyc + 1 end
		self.AnimTrack:SetSlideX( cyc )

	end

	if ( !self.AnimPause:GetToggle() ) then
		ent:FrameAdvance( FrameTime() )
	end

end

function PANEL:RenderIcon()

	local tab = {}
	tab.ent = self.ModelPanel:GetEntity()
	tab.cam_pos = self.ModelPanel:GetCamPos()
	tab.cam_ang = self.ModelPanel:GetLookAng()
	tab.cam_fov = self.ModelPanel:GetFOV()
	tab.lightbox = {}

	for i = 0, 5 do
		local col = self.ModelPanel.DirectionalLight[ i ]
		if ( col ) then
			table.insert( tab.lightbox, Vector( col.r / 255, col.g / 255, col.b / 255 ) )
		end
	end

	tab.lights = self.ModelPanel.LocalLights

	self.SpawnIcon:RebuildSpawnIconEx( tab )

end

function PANEL:SetIcon( icon )

	if ( !IsValid( icon ) ) then return end

	local model = icon:GetModelName()
	self:SetOrigin( icon )

	self.SpawnIcon:SetSize( icon:GetSize() )
	self.SpawnIcon:InvalidateLayout( true )

	-- Set some default sizes to match the icon's aspect ratio
	local w, h = icon:GetSize()
	if ( w / h < 1 ) then
		self:SetSize( 400 + 280, 500 + 400 - 1 )
		self.LeftPanel:SetWide( 400 )
	elseif ( w / h > 1 ) then
		self:SetSize( 600 + 280, 500 - 100 + 1 )
		self.LeftPanel:SetWide( 600 )
	else
		local size = math.min( ScrW() * 0.6, ScrH() * 0.6 )
		self:SetSize( size + 280, size + 100 )
		self.LeftPanel:SetWide( size )
	end

	-- Needs work, but could replace the above
	--local size = math.min( ScrW() * 0.6, ScrH() * 0.6 ) * w / h
	--self:SetSize( size + 280, math.floor( size * h / w ) + 100 )
	--self.LeftPanel:SetWide( size )

	if ( !model or model == "" ) then

		self:SetModel( "error.mdl" )
		self.SpawnIcon:SetSpawnIcon( icon:GetIconName() )
		self:SetCustomIcon( true )

	else

		self:SetModel( model )
		self.SpawnIcon:SetModel( model, icon:GetSkinID(), icon:GetBodyGroup() )
		self:SetCustomIcon( false )

	end

	-- Keep the spawnmenu open
	g_SpawnMenu:SetHangOpen( true )

end

function PANEL:Refresh()

	CloseDermaMenus()

	if ( !self:GetModel() ) then return end

	self.ModelPanel:SetModel( self:GetModel() )
	self.ModelPanel.LayoutEntity = function() self:UpdateEntity( self.ModelPanel:GetEntity() )  end

	local ent = self.ModelPanel:GetEntity()
	if ( !IsValid( ent ) ) then return end

	ent:SetSkin( self.SpawnIcon:GetSkinID() )
	ent:SetBodyGroups( self.SpawnIcon:GetBodyGroup() )
	ent:SetLOD( 0 )

	self:BestGuessLayout()
	self:FillAnimations( ent, self.AnimSearch:GetText() )
	self:SetDefaultLighting()

end

function PANEL:FillAnimations( ent, filter )

	self.AnimList:Clear()

	local sequences = {}
	for i = 0, ent:GetSequenceCount() - 1 do
		local seq = ent:GetSequenceName( i )
		if ( !seq ) then continue end

		seq = string.lower( seq )

		if ( filter && !string.find( seq:lower(), filter:lower(), 1, true ) ) then continue end

		table.insert( sequences, seq )
	end

	for k, v in SortedPairsByValue( sequences ) do

		self.AnimList:AddLine( v )

	end

	self.BodyList:Clear()
	local newItems = 0

	if ( ent:SkinCount() > 1 ) then

		local skinSlider = self.BodyList:Add( "DNumSlider" )
		skinSlider:Dock( TOP )
		skinSlider:DockMargin( 0, 0, 0, 3 )
		skinSlider:SetText( "Skin" )
		skinSlider:SetDark( true )
		skinSlider:SetDecimals( 0 )
		skinSlider:SetMinMax( 0, ent:SkinCount() - 1 )
		skinSlider:SetValue( ent:GetSkin() )
		skinSlider.OnValueChanged = function( s, newVal )
			newVal = math.Round( newVal )

			ent:SetSkin( newVal )

			if ( IsValid( self:GetOrigin() ) ) then self:GetOrigin():SkinChanged( newVal ) end

			-- If we're not using a custom, change our spawnicon
			-- so we save the new skin in the right place...
			if ( !self:GetCustomIcon() ) then
				self.SpawnIcon:SetModel( self.SpawnIcon:GetModelName(), newVal, self.SpawnIcon:GetBodyGroup() )
			end
		end
		newItems = newItems + 1

	end

	for k = 0, ent:GetNumBodyGroups() - 1 do

		if ( ent:GetBodygroupCount( k ) <= 1 ) then continue end

		local bgSlider = self.BodyList:Add( "DNumSlider" )
		bgSlider:Dock( TOP )
		bgSlider:DockMargin( 0, 0, 0, 3 )
		bgSlider:SetDark( true )
		bgSlider:SetDecimals( 0 )
		bgSlider:SetText( ent:GetBodygroupName( k ) )
		bgSlider:SetMinMax( 0, ent:GetBodygroupCount( k ) - 1 )
		bgSlider:SetValue( ent:GetBodygroup( k ) )
		bgSlider.BodyGroupID = k
		bgSlider.OnValueChanged = function( s, newVal )
			newVal = math.Round( newVal )

			ent:SetBodygroup( s.BodyGroupID, newVal )

			if ( IsValid( self:GetOrigin() ) ) then self:GetOrigin():BodyGroupChanged( s.BodyGroupID, newVal ) end

			-- If we're not using a custom, change our spawnicon
			-- so we save the new skin in the right place...
			if ( !self:GetCustomIcon() ) then
				self.SpawnIcon:SetBodyGroup( s.BodyGroupID, newVal )
				self.SpawnIcon:SetModel( self.SpawnIcon:GetModelName(), self.SpawnIcon:GetSkinID(), self.SpawnIcon:GetBodyGroup() )
			end
		end
		newItems = newItems + 1

	end

	if ( newItems > 0 ) then
		self.BodygroupTab.Tab:SetVisible( true )
	else
		self.BodygroupTab.Tab:SetVisible( false )
	end
	local propertySheet = self.PropertySheet
	propertySheet.tabScroller:InvalidateLayout()

end

function PANEL:SetFromEntity( ent )

	if ( !IsValid( ent ) ) then return end

	local bodyStr = ""
	for i = 0, 8 do
		bodyStr = bodyStr .. math.min( ent:GetBodygroup( i ) or 0, 9 )
	end

	self.SpawnIcon:SetModel( ent:GetModel(), ent:GetSkin(), bodyStr )
	self:SetModel( ent:GetModel() )
	self:Refresh()

end

vgui.Register( "IconEditor", PANEL, "DFrame" )
