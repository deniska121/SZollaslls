
local TranslateNames = {
	["Animals"] = "#spawnmenu.category.animals",
	["Combine"] = "#spawnmenu.category.combine",
	["Humans + Resistance"] = "#spawnmenu.category.humans_resistance",
	["Zombies + Enemy Aliens"] = "#spawnmenu.category.zombies_aliens",
	["Other"] = "#spawnmenu.category.other"
}

local function CreateNPCIcon( ent, propPanel )
	return spawnmenu.CreateContentIcon( ent.ScriptedEntityType or "npc", propPanel, {
		nicename	= ent.Name or ent.SpawnName,
		spawnname	= ent.SpawnName,
		material	= ent.IconOverride or "entities/" .. ent.SpawnName .. ".png",
		weapon		= ent.Weapons,
		admin		= ent.AdminOnly
	} )
end

hook.Add( "PopulateNPCs", "AddNPCContent", function( pnlContent, tree, browseNode )

	pnlContent:PopulateFromList( "NPC", tree, {
		SortName = "Name",
		CategoryIcon = "icon16/monkey.png",
		TranslateNames = TranslateNames,
		CreateIconFunc = CreateNPCIcon
	} )

end )

local PANEL = {}

Derma_Hook( PANEL, "Paint", "Paint", "Tree" )
PANEL.m_bBackground = true -- Hack for above

function PANEL:AddCheckbox( text, cvar )
	local DermaCheckbox = self:Add( "DCheckBoxLabel", self )
	DermaCheckbox:Dock( TOP )
	DermaCheckbox:SetText( text )
	DermaCheckbox:SetDark( true )
	DermaCheckbox:SetConVar( cvar)
	DermaCheckbox:SizeToContents()
	DermaCheckbox:DockMargin( 0, 5, 0, 0 )
end

function PANEL:Init()

	self:SetOpenSize( 150 )
	self:DockPadding( 15, 10, 15, 10 )

	self:AddCheckbox( "#menubar.npcs.disableai", "ai_disabled" )
	self:AddCheckbox( "#menubar.npcs.ignoreplayers", "ai_ignoreplayers" )
	self:AddCheckbox( "#menubar.npcs.keepcorpses", "ai_serverragdolls" )
	self:AddCheckbox( "#menubar.npcs.autoplayersquad", "npc_citizen_auto_player_squad" )

	local label = vgui.Create( "DLabel", self )
	label:Dock( TOP )
	label:DockMargin( 0, 5, 0, 0 )
	label:SetDark( true )
	label:SetText( "#menubar.npcs.weapon" )

	local DComboBox = vgui.Create( "DComboBox", self )
	DComboBox:Dock( TOP )
	DComboBox:DockMargin( 0, 0, 0, 0 )
	DComboBox:SetConVar( "gmod_npcweapon" )
	DComboBox:SetSortItems( false )

	DComboBox:AddChoice( "#menubar.npcs.defaultweapon", "", false, "icon16/gun.png" )
	DComboBox:AddChoice( "#menubar.npcs.noweapon", "none", false, "icon16/cross.png" )

	local CustomIcons = list.Get( "ContentCategoryIcons" )
	-- Sort the items by name, and group by category
	local groupedWeps = {}
	for _, v in pairs( list.Get( "NPCUsableWeapons" ) ) do
		local cat = ( v.category or "" ):lower()
		groupedWeps[ cat ] = groupedWeps[ cat ] or {}
		groupedWeps[ cat ][ v.class ] = { title = language.GetPhrase( v.title ), icon = CustomIcons[ v.category or "" ] or "icon16/gun.png" }
	end

	for group, items in SortedPairs( groupedWeps ) do
		DComboBox:AddSpacer()
		for class, info in SortedPairsByMemberValue( items, "title" ) do
			DComboBox:AddChoice( info.title, class, false, info.icon )
		end
	end

	function DComboBox:OnSelect( index, value )
		self:ConVarChanged( self.Data[ index ] )
	end

	self:Open()

end

function PANEL:PerformLayout()
end

vgui.Register( "SpawnmenuNPCSidebarToolbox", PANEL, "DDrawer" )

spawnmenu.AddCreationTab( "#spawnmenu.category.npcs", function()

	local ctrl = vgui.Create( "SpawnmenuContentPanel" )
	ctrl:EnableSearch( "npcs", "PopulateNPCs" )
	ctrl:CallPopulateHook( "PopulateNPCs" )

	local sidebar = ctrl.ContentNavBar
	sidebar.Options = vgui.Create( "SpawnmenuNPCSidebarToolbox", sidebar )
	sidebar.Options:Dock( BOTTOM )

	return ctrl

end, "icon16/monkey.png", 20 )
